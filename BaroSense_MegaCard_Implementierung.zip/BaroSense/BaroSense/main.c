/*-------------------------------------------------------------------------*\
| Datei:        main.c
| Version:      1.0
| Projekt:      Einfuehrung in das Programmieren des Atmega16
| Beschreibung: Grundgeruest fuer die Anzeigebibliothek
| Schaltung:    MEGACARD V5.5
| Autor:
| Erstellung:
|
| Aenderung:
\*-------------------------------------------------------------------------*/
#include <avr/io.h>
#include <util/delay.h>
#include "display.h"
#include <avr/interrupt.h>
#define Z_MAX 255 //maximaler ADC-Wert
#define Vs_max 5 

ISR(ADC_vect)
{
	unsigned char Z = ADCH;
	float a = 0.009;
	float b = 0.095;
	unsigned char Vdd = 5;
	
	float Vsensor = Vs_max * Z/(Z_MAX +1);
	
	float P = (Vsensor/Vdd *a) - (b/a);
	
	display_printf_pos(0,6, "V: %2f", P);
	
	
}


void init (void)
{   
   DDRA &= ~(1<<PA5); //Pin PA5 auf Eingang stellen
   char kanal = 5;
   
   ADCSRA |= (1<<ADATE);	//Betriebsmodus auf Dauerwandlung stellen
   ADCSRA |= (1<<ADPS1) | (1<<ADPS2);		//ADC Vorteiler auf 64 (f_ADC = 187,5 kHz)
   ADMUX |= kanal;			//Kanal einstellen (unipolarer Messmodus)
   ADMUX |= (1<<ADLAR);	//ADCW linksb�ndig lesen
   ADMUX |= (1<<REFS0);	//Referenzspannug auf Vcc ~5V stellen
   
   ADCSRA |= (1<<ADEN);	//ADC einschalten
   ADCSRA |= (1<<ADSC);	//Wandlung starten
   
   ADCSRA |= (1<<ADIE);	//Interrupt spezifisch freigeben
   sei();					//Interrupts global freigeben
}

int main (void)
{
   init ();        // Aufruf der Grundinitialisierungen
   display_init(); // Initialisierung der Anzeige
   
   display_string_pos (0, 4, "  HTL Rankweil");

   while (1)
   {
		
   }

   return 0;
}
